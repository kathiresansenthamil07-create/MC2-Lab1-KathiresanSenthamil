import type { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'home',
    loadComponent: () => import('./home/home.page').then((m) => m.HomePage),
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: 'notes',
    loadComponent: () => import('./pages/notes/notes.page').then((m) => m.NotesPage),
  },
  {
    path: 'contacts',
    loadComponent: () => import('./pages/contacts/contacts.page').then((m) => m.ContactsPage),
  },
];
