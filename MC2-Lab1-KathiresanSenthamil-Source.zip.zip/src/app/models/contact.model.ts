
export interface Contact {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  createdAt: Date | null;
}

export type NewContact = Pick<
  Contact,
  'name' | 'phone' | 'email' | 'address'
>;
