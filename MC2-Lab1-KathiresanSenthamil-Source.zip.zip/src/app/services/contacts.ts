
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
  Timestamp,
} from 'firebase/firestore';

import { db } from '../firebase';
import { Contact, NewContact } from '../models/contact.model';

@Injectable({
  providedIn: 'root',
})
export class ContactsService {
  private contactsRef = collection(db, 'contacts');

  // READ: Listen for real-time changes in the contacts collection.
  listContacts(): Observable<Contact[]> {
    const q = query(this.contactsRef, orderBy('createdAt', 'desc'));

    return new Observable<Contact[]>((subscriber) => {
      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const contacts = snapshot.docs.map((d) => {
            const data = d.data({ serverTimestamps: 'estimate' });

            const created = data['createdAt'];

            return {
              id: d.id,
              name: data['name'] ?? '',
              phone: data['phone'] ?? '',
              email: data['email'] ?? '',
              address: data['address'] ?? '',
              createdAt:
                created instanceof Timestamp ? created.toDate() : null,
            } as Contact;
          });

          subscriber.next(contacts);
        },
        (error) => subscriber.error(error),
      );

      return unsubscribe;
    });
  }

  // CREATE: Add a new contact to Firestore.
  addContact(contact: NewContact) {
    return addDoc(this.contactsRef, {
      name: contact.name.trim(),
      phone: contact.phone.trim(),
      email: contact.email.trim(),
      address: contact.address.trim(),
      createdAt: serverTimestamp(),
    });
  }

  // UPDATE: Edit an existing contact.
  updateContact(id: string, contact: NewContact) {
    return updateDoc(doc(db, 'contacts', id), {
      name: contact.name.trim(),
      phone: contact.phone.trim(),
      email: contact.email.trim(),
      address: contact.address.trim(),
    });
  }

  // DELETE: Remove a contact from Firestore.
  deleteContact(id: string) {
    return deleteDoc(doc(db, 'contacts', id));
  }
}
