import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonButton,
  IonItem,
  IonInput,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonLabel,
} from '@ionic/angular';

import { ContactsService } from '../../services/contacts';
import { NewContact } from '../../models/contact.model';

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.page.html',
  styleUrls: ['./contacts.page.scss'],
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonButton,
    IonItem,
    IonInput,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonLabel,
  ],
})
export class ContactsPage {
  name = '';
  phone = '';
  email = '';
  address = '';

  contacts$ = this.contactsService.listContacts();

  constructor(private contactsService: ContactsService) {}

  async addContact() {
    if (!this.name.trim()) {
      return;
    }

    const contact: NewContact = {
      name: this.name,
      phone: this.phone,
      email: this.email,
      address: this.address,
    };

    try {
      await this.contactsService.addContact(contact);

      this.name = '';
      this.phone = '';
      this.email = '';
      this.address = '';
    } catch (error) {
      console.error('Error adding contact:', error);
    }
  }

  async deleteContact(id: string) {
    try {
      await this.contactsService.deleteContact(id);
    } catch (error) {
      console.error('Error deleting contact:', error);
    }
  }
}
