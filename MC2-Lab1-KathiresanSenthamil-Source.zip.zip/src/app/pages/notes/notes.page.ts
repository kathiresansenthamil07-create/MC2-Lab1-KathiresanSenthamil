
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonButton,
  IonItem,
  IonInput,
  IonTextarea,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonCheckbox,
  IonLabel,
} from '@ionic/angular';

import { NotesService } from '../../services/notes';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.page.html',
  styleUrls: ['./notes.page.scss'],
  imports: [
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonButton,
    IonItem,
    IonInput,
    IonTextarea,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonCheckbox,
    IonLabel,
    CommonModule,
    FormsModule,
  ],
})
export class NotesPage {
  title = '';
  body = '';

  notes$ = this.notesService.listNotes();

  constructor(private notesService: NotesService) {}

  async addNote() {
    if (!this.title.trim()) return;

    try {
      await this.notesService.addNote({
        title: this.title,
        body: this.body,
      });

      this.title = '';
      this.body = '';
    } catch (error) {
      console.error('Error adding note:', error);
    }
  }

  async toggleNote(id: string, done: boolean) {
    try {
      await this.notesService.setDone(id, done);
    } catch (error) {
      console.error('Error updating note:', error);
    }
  }

  async deleteNote(id: string) {
    try {
      await this.notesService.deleteNote(id);
    } catch (error) {
      console.error('Error deleting note:', error);
    }
  }
}
