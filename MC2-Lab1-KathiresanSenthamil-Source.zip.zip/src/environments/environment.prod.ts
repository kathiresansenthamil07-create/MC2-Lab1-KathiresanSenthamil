export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCj35LazlOK1mizCaQp9W3Gu3BZtTG-bFg",
    authDomain: "mc2-lab1-kathiresan.firebaseapp.com",
    projectId: "mc2-lab1-kathiresan",
    storageBucket: "mc2-lab1-kathiresan.firebasestorage.app",
    messagingSenderId:  "926024308027",
    appId: "1:926024308027:web:e600eb15d5871044a3931e",
  },
};